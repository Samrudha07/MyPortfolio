import './App.css';
import Headers from "./Components/Header"
// import Newheader from "./Components/Newheader"

function App() {
  return (
    <>
      <Headers/>
      {/* <Newheader/> */}
    </>
  );
}

export default App;
